package latihan1;

public class GajiPelatih extends Gaji {
	
	public GajiPelatih () {
		super();
	}
	
	public GajiPelatih(int gaji) {
		super(gaji);
	}

}

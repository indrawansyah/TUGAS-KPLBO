package latihan2;

public class Tim {
	private String nama ;
	
	public Tim () {
		setNama("");
	}
	
	public Tim (String nama) {
		this.setNama(nama) ;
	}

	public String getNama() {
		return nama;
	}

	public void setNama(String nama) {
		this.nama = nama;
	}

	
}


package latihan2;

public interface Kartu {
	public boolean otentikasi(String PIN);

	public String encode(String PIN);

}

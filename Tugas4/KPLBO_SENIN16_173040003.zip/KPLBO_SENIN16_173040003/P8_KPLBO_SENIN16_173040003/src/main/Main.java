package main;

import frames.Kalkulator;

public class Main {
	public static void main(String[] args) {
		new Kalkulator();
	}

}

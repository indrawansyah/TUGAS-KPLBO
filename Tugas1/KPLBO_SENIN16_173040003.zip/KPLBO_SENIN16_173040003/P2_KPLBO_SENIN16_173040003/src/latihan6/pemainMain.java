package latihan6;

public class pemainMain {
	public static void main(String[] args) {
		pemain p = new pemain(22, "Febry", 2000000);
		System.out.println(p);
		
		System.out.println("*****************");
		
		pemain p1 = new pemain(10, "Sergio Van Djik",5000000);
		System.out.println(p1);
	}
}
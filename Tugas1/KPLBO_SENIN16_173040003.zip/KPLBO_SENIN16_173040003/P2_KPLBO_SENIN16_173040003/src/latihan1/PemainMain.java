package latihan1;

public class PemainMain {

	public static void main (String[] args) {
		Pemain p = new Pemain();
		p.setNama("David Seaman");
		System.out.println(p);
	}

}

package latihan5;

public class pemainMain {
	public static void main(String[] args) {
		pemain p = new pemain();
		p.setNoPunggung(1);
		p.setNama("I Made");
		System.out.println(p);
		
		pemain p1 = new pemain();
		p1.setNoPunggung(6);
		p1.setNama("Vujovic");
		System.out.println(p1);
	
		pemain p2 = new pemain();
		p2.setNoPunggung(7);
		p2.setNama("Atep");
		System.out.println(p2);
		
		pemain p3 = new pemain();
		p3.setNoPunggung(22);
		p3.setNama("Febry");
		System.out.println(p3);
	}
}

package latihan5;

public class Pemain {
	private String nama;
	private String nomorPunggung;

	
	public Pemain() {
		nama = "";
		nomorPunggung="0";
	}
	
	public Pemain(String nama) {
		this.nama=nama;
	}
	public Pemain(String nama, String nomorPunggung) {
		this.nama=nama;
		this.nomorPunggung=nomorPunggung;
		
	}

	
	public String getNama() {
		return nama;
	}


	public void setNama(String nama) {
		this.nama = nama;
	}


	public String getNomorPunggung() {
		return nomorPunggung;
	}


	public void setNomorPunggung(String nomorPunggung) {
		this.nomorPunggung = nomorPunggung;
	}


	public String toString() {
		return nama+":"+nomorPunggung;
	}
	

}

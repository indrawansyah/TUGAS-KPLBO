package latihan5;


public class PemainMain {
	public static void main(String[] args) {
		Pemain pemain1 = new Pemain("1","I Made");
		Pemain pemain2 =  new Pemain("6","Vujovic");
		Pemain pemain3 =  new Pemain("7","Atep");
		Pemain pemain4 =  new Pemain("22","Febry");
		System.out.println(pemain1 +"\n"+pemain2 +"\n"+pemain3 +"\n"+pemain4);
		
	}
}

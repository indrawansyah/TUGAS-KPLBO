package latihan3;


public class PemainMain {
	public static void main(String[] args) {
		Pemain pemain = new Pemain();
		
		Pemain pemain1= new Pemain();
		pemain1.setNama("David Seaman");
		pemain1.setNomorPunggung("1");
		System.out.println(pemain1);
		
		Pemain pemain2 =  new Pemain("Toni Adams");
		pemain2.setNomorPunggung("6");
		System.out.println(pemain2);
		
		Pemain pemain3 =  new Pemain("Thiery Henry","11");
		System.out.println(pemain3);
		
	}
}

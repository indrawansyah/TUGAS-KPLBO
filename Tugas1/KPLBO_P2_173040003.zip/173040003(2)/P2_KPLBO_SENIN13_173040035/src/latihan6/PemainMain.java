package latihan6;


public class PemainMain {
	public static void main(String[] args) {
		Pemain pemain1 = new Pemain("1","I Made",100000);
		Pemain pemain2 =  new Pemain("6","Vujovic",400000);
		Pemain pemain3 =  new Pemain("7","Atep",900000);
		Pemain pemain4 =  new Pemain("22","Febry",1020000);
		System.out.println(pemain1 +"\n"+pemain2 +"\n"+pemain3 +"\n"+pemain4);
		
	}
}

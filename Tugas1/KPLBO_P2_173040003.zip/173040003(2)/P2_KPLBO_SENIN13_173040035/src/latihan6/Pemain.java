package latihan6;

public class Pemain {
	private String nama;
	private String nomorPunggung;
	private int gaji;
	

	
	public Pemain() {
		nama = "";
		nomorPunggung="0";
	}
	
	public Pemain(String nama) {
		this.nama=nama;
	}
	public Pemain(String nama, String nomorPunggung, int gaji) {
		this.nama=nama;
		this.nomorPunggung=nomorPunggung;
		this.gaji=gaji;
		
	}
	public int hitungGajiPerBulan(){
		return gaji *4;
		
	}
	public int gaji() {
		return gaji;
	}
	
	public String getNama() {
		return nama;
	}


	public void setNama(String nama) {
		this.nama = nama;
	}


	public String getNomorPunggung() {
		return nomorPunggung;
	}


	public void setNomorPunggung(String nomorPunggung) {
		this.nomorPunggung = nomorPunggung;
	}


	public String toString() {
		return nama+":"+nomorPunggung+"\n"
				+"gaji perminggu "+gaji+"\n"
				+"gaji perbulan "+hitungGajiPerBulan()+"\n";
	}
	

}

package latihan2;

public class PemainMain {
	public static void main(String[] args) {
		Pemain pemain = new Pemain();
		pemain.setNama("David Seaman");
		pemain.setNomorPunggung("1");
		System.out.println(pemain);
	}
}

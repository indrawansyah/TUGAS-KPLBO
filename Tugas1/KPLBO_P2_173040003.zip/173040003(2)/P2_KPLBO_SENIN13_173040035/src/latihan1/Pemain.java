package latihan1;

public class Pemain {
private String nama;

public String getNama() {
	return nama;
}
public void setNama(String nama) {
	this.nama=nama;
}
public String toString() {
	return nama;
}

}

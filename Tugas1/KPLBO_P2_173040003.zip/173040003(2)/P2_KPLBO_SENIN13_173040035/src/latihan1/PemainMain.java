package latihan1;

public class PemainMain {
	public static void main(String[] args) {
		Pemain pemain = new Pemain();
		pemain.setNama("David Seaman");
		
		System.out.println(pemain);
	}
}

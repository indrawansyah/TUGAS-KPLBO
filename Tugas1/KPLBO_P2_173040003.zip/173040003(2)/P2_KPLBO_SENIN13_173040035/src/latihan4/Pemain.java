package latihan4;

public class Pemain {
	private String nama;
	private int nomorPunggung;

	
	public Pemain() {
		nama = "";
		nomorPunggung=0;
	}

	
	public String getNama() {
		return nama;
	}


	public void setNama(String nama) {
		this.nama = nama;
	}


	public int getNomorPunggung() {
		return nomorPunggung;
	}


	public void setNomorPunggung(int nomorPunggung) {
		this.nomorPunggung = nomorPunggung;
	}


	public String toString() {
		return nama+":"+nomorPunggung;
	}
	

}

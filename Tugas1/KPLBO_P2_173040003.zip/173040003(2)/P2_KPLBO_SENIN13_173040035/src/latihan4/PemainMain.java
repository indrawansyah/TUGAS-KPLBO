package latihan4;


public class PemainMain {
	public static void main(String[] args) {
		Pemain pemain = new Pemain();
		System.out.println(pemain);
	}
}

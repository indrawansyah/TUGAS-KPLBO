/**
 * 
 */
/**
 * @author SB601-28
 *
 */
module Latihan1 {
}